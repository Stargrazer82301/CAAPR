#!/bin/sh
rm -rf *.pyc
rm -rf *.class