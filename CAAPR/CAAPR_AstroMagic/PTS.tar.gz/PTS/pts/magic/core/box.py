#!/usr/bin/env python
# -*- coding: utf8 -*-
# *****************************************************************
# **       PTS -- Python Toolkit for working with SKIRT          **
# **       © Astronomical Observatory, Ghent University          **
# *****************************************************************

## \package pts.magic.core.box Contains the Box class.

# -----------------------------------------------------------------

# Ensure Python 3 functionality
from __future__ import absolute_import, division, print_function

# Import standard modules
import math
import numpy as np
from scipy import ndimage

# Import the relevant PTS classes and modules
from ..basics.vector import Position, Extent
from ..basics.geometry import Rectangle
from ..tools import cropping, fitting, interpolation, plotting, statistics
from ...core.tools.logging import log
from ...core.basics.distribution import Distribution

# -----------------------------------------------------------------

class CutoutMask(np.ndarray):

    """
    This class ...
    """

    def __new__(cls, data, x_min, x_max, y_min, y_max):

        """
        This function ...
        :param cls:
        :param data:
        :param x_min:
        :param x_max:
        :param y_min:
        :param y_max:
        :return:
        """

        obj = np.asarray(data, dtype=bool).view(cls)
        obj.x_min = x_min
        obj.x_max = x_max
        obj.y_min = y_min
        obj.y_max = y_max

        return obj

    # -----------------------------------------------------------------

    @property
    def xsize(self):

        """
        This function ...
        :return:
        """

        return self.shape[1]

    # -----------------------------------------------------------------

    @property
    def ysize(self):

        """
        This function ...
        :return:
        """

        return self.shape[0]

    # -----------------------------------------------------------------

    def as_cutout(self, cutout, padding_value=0.0):

        """
        This function ...
        :param cutout:
        :param padding_value:
        :return:
        """

        rel_x_min = cutout.x_min - self.x_min
        rel_x_max = cutout.x_max - self.x_min

        rel_y_min = cutout.y_min - self.y_min
        rel_y_max = cutout.y_max - self.y_min

        if rel_x_min < 0 or rel_y_min < 0 or rel_x_max > self.xsize or rel_y_max > self.ysize:

            # Create box
            new = np.zeros((cutout.ysize, cutout.xsize))
            if padding_value != 0: new[:,:] = padding_value

            # Normal:
            a = 0
            b = cutout.ysize
            c = 0
            d = cutout.xsize
            aa = rel_y_min
            bb = rel_y_max
            cc = rel_x_min
            dd = rel_x_max

            # Cross-over on the lower x border
            if rel_x_min < 0:
                c = 0 - rel_x_min
                cc = 0

            # Cross-over on the lower y border
            if rel_y_min < 0:
                a = 0 - rel_y_min
                aa = 0

            # Cross-over on the upper x border
            if rel_x_max > self.xsize:

                d = self.xsize - rel_x_min
                dd = self.xsize

            # Cross-over on the upper y border
            if rel_y_max > self.ysize:

                b = self.ysize - rel_y_min
                bb = self.ysize

            new[a:b, c:d] = self[aa::bb, cc::dd]

            # Return the new CutoutMask
            return CutoutMask(new, cutout.x_min, cutout.x_max, cutout.y_min, cutout.y_max)

        # Return a new CutoutMask
        else: return CutoutMask(self[rel_y_min:rel_y_max, rel_x_min:rel_x_max], cutout.x_min, cutout.x_max, cutout.y_min, cutout.y_max)

# -----------------------------------------------------------------

class Box(np.ndarray):

    """
    This class ...
    """

    def __new__(cls, data, x_min, x_max, y_min, y_max):

        """
        This function ...
        :param cls:
        :param data:
        :param x_min:
        :param x_max:
        :param y_min:
        :param y_max:
        :return:
        """

        # Create an object of the Box class
        obj = np.asarray(data).view(cls)

        # Set attributes of the object
        obj.x_min = x_min
        obj.x_max = x_max
        obj.y_min = y_min
        obj.y_max = y_max

        # Return the object
        return obj

    # -----------------------------------------------------------------

    @classmethod
    def cutout(cls, frame, center, x_radius, y_radius=None):

        """
        This class method ...
        :param frame:
        :param center:
        :param x_radius:
        :param y_radius:
        :return:
        """

        if y_radius is None: y_radius = x_radius

        # Crop the frame
        cropped, x_min, x_max, y_min, y_max = cropping.crop(frame, center.x, center.y, x_radius, y_radius)

        # Check that the center position lies within the box
        assert (x_min <= center.x < x_max and y_min <= center.y < y_max)

        # Return a new box
        return cls(cropped, x_min, x_max, y_min, y_max)

    # -----------------------------------------------------------------

    @classmethod
    def cutout_limits(cls, frame, x_min, x_max, y_min, y_max, absolute=False):

        """
        This function ...
        :param frame:
        :param x_min:
        :param x_max:
        :param y_min:
        :param y_max:
        :param absolute:
        :return:
        """

        # Crop the frame
        if absolute: cropped = cropping.crop_absolute(frame, x_min, x_max, y_min, y_max)
        else: cropped, x_min, x_max, y_min, y_max = cropping.crop_direct(frame, x_min, x_max, y_min, y_max)

        # Return a new box
        return cls(cropped, x_min, x_max, y_min, y_max)

    # -----------------------------------------------------------------

    @classmethod
    def from_rectangle(cls, frame, rectangle, absolute=False):

        """
        This function ...
        :param frame:
        :param rectangle:
        :param absolute:
        :return:
        """

        # TODO: fix this for rotated rectangles

        # Convert into integers
        x_min = int(round(rectangle.x_min))
        x_max = int(round(rectangle.x_max))
        y_min = int(round(rectangle.y_min))
        y_max = int(round(rectangle.y_max))

        if x_min == x_max:
            x_min = int(math.floor(rectangle.x_min))
            x_max = int(math.ceil(rectangle.x_max))
        if y_min == y_max:
            y_min = int(math.floor(rectangle.y_min))
            y_max = int(math.ceil(rectangle.y_max))

        if x_max - x_min < 2: x_max = x_min + 2
        if y_max - y_min < 2: y_max = y_min + 2

        # Create cutout
        return cls.cutout_limits(frame, x_min, x_max, y_min, y_max, absolute)

    # -----------------------------------------------------------------

    @classmethod
    def from_ellipse(cls, frame, ellipse, shape=None):

        """
        This function ...
        :param frame:
        :param ellipse:
        :param shape:
        :return:
        """

        # Get bouding box
        rectangle = ellipse.bounding_box

        # ...
        if shape is not None: rectangle = Rectangle(rectangle.center, Extent(0.5 * shape.x, 0.5 * shape.y))

        return cls.from_rectangle(frame, rectangle, absolute=(shape is not None))

    # -----------------------------------------------------------------

    @property
    def origin(self):

        """
        This function ...
        :return:
        """

        return Position(self.x_min, self.y_min)

    # -----------------------------------------------------------------

    def box_like(self, box):

        """
        This function ...
        :param box:
        :return:
        """

        rel_y_min = box.y_min - self.y_min
        rel_y_max = box.y_max - self.y_min

        rel_x_min = box.x_min - self.x_min
        rel_x_max = box.x_max - self.x_min

        data = self[rel_y_min:rel_y_max, rel_x_min:rel_x_max]

        # Create the new box and return it
        return Box(data, box.x_min, box.x_max, box.y_min, box.y_max)

    # -----------------------------------------------------------------

    def zoom(self, center, factor):

        """
        This function ...
        :param center:
        :param factor:
        :return:
        """

        # Calculate the size of the smaller box
        new_xsize = int(round(0.5 * self.xsize / factor))
        new_ysize = int(round(0.5 * self.ysize / factor))

        # Calculate the relative coordinate of the center
        rel_center = self.rel_position(center)

        # Create a smaller box
        data, rel_x_min, rel_x_max, rel_y_min, rel_y_max = cropping.crop(self, rel_center.x, rel_center.y, new_xsize, new_ysize)

        # Create the new box
        return Box(data, rel_x_min+self.x_min, rel_x_max+self.x_min, rel_y_min+self.y_min, rel_y_max+self.y_min)

    # -----------------------------------------------------------------

    def __array_finalize__(self, obj):

        """
        This function ...
        :param obj:
        :return:
        """

        # see InfoArray.__array_finalize__ for comments
        if obj is None: return

        self.x_min = getattr(obj, 'x_min', None)
        self.x_max = getattr(obj, 'x_max', None)
        self.y_min = getattr(obj, 'y_min', None)
        self.y_max = getattr(obj, 'y_max', None)

    # -----------------------------------------------------------------

    def plot(self, frame=None):

        """
        This function ...
        :param frame:
        :return:
        """

        plotting.plot_box(self)

        # If frame is not None, plot 'zoom' plot

    # -----------------------------------------------------------------

    @property
    def xsize(self):

        """
        This property ...
        :return:
        """

        return self.shape[1]

    # -----------------------------------------------------------------

    @property
    def ysize(self):

        """
        This property ...
        :return:
        """

        return self.shape[0]

    # -----------------------------------------------------------------

    @property
    def x_slice(self):

        """
        This property ...
        :return:
        """

        return slice(self.x_min, self.x_max)

    # -----------------------------------------------------------------

    @property
    def y_slice(self):

        """
        This property ...
        :return:
        """

        return slice(self.y_min, self.y_max)

    # -----------------------------------------------------------------

    def rel_position(self, position):

        """
        This function ...
        :param position:
        :return:
        """

        # Return the relative position
        return Position(position.x - self.x_min, position.y - self.y_min)

    # -----------------------------------------------------------------

    def abs_position(self, position):

        """
        This function ...
        :param position:
        :return:
        """

        # Return the absolute position
        return Position(position.x + self.x_min, position.y + self.y_min)

    # -----------------------------------------------------------------

    def fit_polynomial(self, order, mask=None):

        """
        This function ...
        :param order:
        :param mask:
        :return:
        """

        # Do the fitting
        polynomial = fitting.fit_polynomial(self, order, mask=mask)

        # Evaluate the polynomial
        data = fitting.evaluate_model(polynomial, 0, self.xsize, 0, self.ysize)

        # Return a new box
        return Box(data, self.x_min, self.x_max, self.y_min, self.y_max)

    # -----------------------------------------------------------------

    def gaussian_filter(self, sigma):

        """
        This function ...
        :param sigma:
        :return:
        """

        # Apply the filter
        data = ndimage.filters.gaussian_filter(self, sigma=sigma)

        # Return a new box
        return Box(data, self.x_min, self.x_max, self.y_min, self.y_max)

    # -----------------------------------------------------------------

    def fit_model(self, center, model_name, sigma=None, max_center_offset=None, amplitude=None, max_sigma_offset=None):

        """
        This function ...
        :param center:
        :param model_name:
        :param sigma:
        :param max_center_offset:
        :param amplitude:
        :param max_sigma_offset:
        :return:
        """

        # Calculate the relative coordinate of the center
        rel_center = self.rel_position(center)

        # Fit a 2D Gaussian to the data
        if model_name == "Gaussian":

            # Do the fitting
            model = fitting.fit_2D_Gaussian(self, rel_center, sigma=sigma, max_center_offset=max_center_offset, amplitude=amplitude, max_sigma_offset=max_sigma_offset)

        # Fit an Airy Disk model to the data
        elif model_name == "Airy":

            # See https://en.wikipedia.org/wiki/Airy_disk#Approximation_using_a_Gaussian_profile and
            # http://astropy.readthedocs.org/en/latest/api/astropy.modeling.functional_models.AiryDisk2D.html#astropy.modeling.functional_models.AiryDisk2D
            #sigma = 0.42 * airy.radius * 0.81989397882
            radius = sigma / (0.42 * 0.81989397882) if sigma is not None else None

            # Do the fitting
            model = fitting.fit_2D_Airy(self, rel_center, radius=radius, max_center_offset=max_center_offset, amplitude=amplitude)

        # Fit a 2D (vertically) shifted Gaussian to the data
        elif model_name == "ShiftedGaussian":

            # Do the fitting
            model = fitting.fit_2D_ShiftedGaussian(self, rel_center, sigma=sigma, max_center_offset=max_center_offset, amplitude=amplitude)

        # Unknown model name
        else: raise ValueError("Model name should be 'Gaussian' or 'Airy'")

        # Shift the position of the model so that it represents its absolute position in the frame
        fitting.shift_model(model, self.x_min, self.y_min)

        # Return the model
        return model

    # -----------------------------------------------------------------

    def evaluate_model(self, model):

        """
        This function ...
        :param model:
        :return:
        """

        # Make a local copy of the model so that we can adapt its position to be relative to this box
        rel_model = fitting.shifted_model(model, -self.x_min, -self.y_min)

        # Create x and y meshgrid for evaluating
        y_values, x_values = np.mgrid[:self.ysize, :self.xsize]

        # Evaluate the model
        data = rel_model(x_values, y_values)

        # Return a new box
        return Box(data, self.x_min, self.x_max, self.y_min, self.y_max)

    # -----------------------------------------------------------------

    def interpolated(self, mask, method, no_clip_mask=None, plot=False):

        """
        This function ...
        :param mask:
        :param method:
        :param no_clip_mask:
        :return:
        """

        # Fit a polynomial to the data
        if method == "polynomial":
            try:
                return self.fit_polynomial(3, mask=mask)
            except TypeError:
                #from ..tools import plotting
                log.debug("Error while fitting polynomial to the box ...")
                log.debug("cutout = " + str(type(self)) + " " + str(mask.shape))
                log.debug("mask = " + str(type(mask)) + " " + str(mask.shape))
                #print("HERE!")
                #plotting.plot_box(self)
                #plotting.plot_box(mask)
                #plotting.plot_box(np.ma.masked_array(self, mask=mask))
                #print("AND HEREEE!!!")
                mask = mask.eroded(connectivity=2, iterations=1)
                #plotting.plot_box(np.ma.masked_array(self, mask=mask))
                return self.fit_polynomial(3, mask=mask)

        # Interpolate using the local mean method
        elif method == "local_mean":

            try:
                # Calculate the interpolated data
                data = interpolation.in_paint(self, mask)
            except IndexError:
                log.debug("Error while inpainting using the local_mean method ...")
                data = np.zeros((self.ysize, self.xsize))

            # Create and return a new box
            return Box(data, self.x_min, self.x_max, self.y_min, self.y_max)

        # Interpolate using inverse distance weighing
        elif method == "idw":

            # Calculate the interpolated data
            data = interpolation.in_paint(self, mask, method="idw")

            # Create and return a new box
            return Box(data, self.x_min, self.x_max, self.y_min, self.y_max)

        # Calculate the mean value of the data
        elif method == "mean":

            mean = np.ma.mean(np.ma.masked_array(self, mask=mask))
            return self.full(mean)

        # Calculate the median value of the data
        elif method == "median":

            median = np.ma.median(np.ma.masked_array(self, mask=mask))
            return self.full(median)

        # Use the biharmonic method of the Scikit-image package
        elif method == "biharmonic":

            data = interpolation.inpaint_biharmonic(self, mask)

            # Check whether the data is NaN-free, because this method will sometimes fail to interpolate and
            # just put NaNs for the pixels that are covered by the mask. (I still have to check under which
            # conditions but it has something to do with being close to the boundary)
            if np.any(np.isnan(data)):

                #from ..tools import plotting
                #plotting.plot_box(normalized)
                #plotting.plot_box(mask)

                # Interpolate by local_mean, this does not leave nans
                data = interpolation.in_paint(data, mask)

            return Box(data, self.x_min, self.x_max, self.y_min, self.y_max)

        # Use the 'PTS' method
        elif method == "pts":


            #test = no_clip_mask is not None

            # POLYNOMIAL WITHOUT SIGMA-CLIPPING

            """
            polynomial_fit_mask = mask if no_clip_mask is None else no_clip_mask  # determine the mask to use for fitting the polynomial
            order = 3
            try:
                polynomial = fitting.fit_polynomial(self, order, mask=polynomial_fit_mask)
            except TypeError:
                try:
                    polynomial_fit_mask = polynomial_fit_mask.eroded(connectivity=2, iterations=1)
                    polynomial = fitting.fit_polynomial(self, order, mask=polynomial_fit_mask)
                except TypeError:
                    log.warning("Cannot interpolate over this box ...")
                    return self.copy()

            # Evaluate the polynomial
            poly_data = fitting.evaluate_model(polynomial, 0, self.xsize, 0, self.ysize)

            subtracted = self - poly_data

            if test: plotting.plot_difference(self, poly_data, title="without sigma-clipping")
            """

            #no_clip_mask = None
            #polynomial_fit_mask = mask if no_clip_mask is None else no_clip_mask # determine the mask to use for fitting the polynomial

            polynomial_fit_mask = mask

            order = 3
            try: polynomial = fitting.fit_polynomial(self, order, mask=polynomial_fit_mask)
            except TypeError:
                try:
                    polynomial_fit_mask = polynomial_fit_mask.eroded(connectivity=2, iterations=1)
                    polynomial = fitting.fit_polynomial(self, order, mask=polynomial_fit_mask)
                except TypeError:
                    log.warning("Cannot interpolate over this box ...")
                    return self.copy()

            # Evaluate the polynomial
            poly_data = fitting.evaluate_model(polynomial, 0, self.xsize, 0, self.ysize)

            subtracted = self - poly_data

            if plot: plotting.plot_difference(self, poly_data, title="with sigma-clipping")

            #if no_clip_mask is not None:
            #    plotting.plot_difference(self, poly_data)
            #    plotting.plot_box(subtracted)
            #    plotting.plot_box(np.ma.array(subtracted, mask=mask))
            #    from ..tools import statistics
            #    new_mask = statistics.sigma_clip_mask(subtracted, sigma_level=2.0, mask=mask)
            #    plotting.plot_box(np.ma.array(subtracted, mask=new_mask))
            #    background_pixels = subtracted[new_mask.inverse()]
            #else:

            #if test:
            #    new_mask = statistics.sigma_clip_mask(subtracted, sigma_level=2.0, mask=mask)
            #    background_pixels = subtracted[new_mask.inverse()]
            #else: background_pixels = subtracted[mask.inverse()]

            background_pixels = subtracted[mask.inverse()]

            #distribution = Distribution.from_values(background_pixels)
            #gaussian = distribution.fit_gaussian()
            #center = gaussian.mean
            #stddev = gaussian.stddev
            #distribution.plot(model=gaussian)

            center = np.mean(background_pixels)
            stddev = np.std(background_pixels)

            #print("amplitude", gaussian.amplitude)
            #print("center", center)
            #print("stddev", stddev)

            # Generate random pixel values
            random = np.random.normal(center, stddev, self.shape)

            if plot: plotting.plot_box(random, title="random (center value=" + str(center) + " stddev=" + str(stddev) + ")")

            # Fit polynomial again but with no-sigma-clipped-mask

            if no_clip_mask is not None:

                polynomial_fit_mask = no_clip_mask
                order = 3
                try:
                    polynomial = fitting.fit_polynomial(self, order, mask=polynomial_fit_mask)
                except TypeError:
                    try:
                        polynomial_fit_mask = polynomial_fit_mask.eroded(connectivity=2, iterations=1)
                        polynomial = fitting.fit_polynomial(self, order, mask=polynomial_fit_mask)
                    except TypeError:
                        log.warning("Cannot interpolate over this box ...")
                        return self.copy()

                # Evaluate the polynomial
                poly_data = fitting.evaluate_model(polynomial, 0, self.xsize, 0, self.ysize)

                if plot: plotting.plot_difference(self, poly_data, title="polynomial with sigma-clipping")

            return Box(random + poly_data, self.x_min, self.x_max, self.y_min, self.y_max)

        # Invalid option
        else: raise ValueError("Unknown interpolation method")

    # -----------------------------------------------------------------

    def value(self, position):

        """
        This function ...
        :param position:
        :return:
        """

        # Get the x and y coordinate of the corresponding pixel
        x = int(round(position.x - self.x_min))
        y = int(round(position.y - self.y_min))

        # Return the pixel value
        return self[y, x]

    # -----------------------------------------------------------------

    def contains(self, position):

        """
        This function ...
        :param position:
        :return:
        """

        # Convert to relative position
        rel_position = self.rel_position(position)

        # Calculate the pixel coordinates of the position
        x_pixel = int(round(rel_position.x))
        y_pixel = int(round(rel_position.y))

        # Check whether this box contains the position
        if x_pixel < 0 or y_pixel < 0 or x_pixel >= self.xsize or y_pixel >= self.ysize: return False
        else: return True

    # -----------------------------------------------------------------

    def replace(self, frame, where=None):

        """
        This function ...
        :param frame:
        :param where:
        :return:
        """

        # Replace the pixel values in the frame
        if where is None: frame[self.y_min:self.y_max, self.x_min:self.x_max] = self
        else: frame[self.y_min:self.y_max, self.x_min:self.x_max][where] = self[where]

        #from ..tools import plotting
        #plotting.plot_box(frame[self.y_min:self.y_max, self.x_min:self.x_max])
        #plotting.plot_box(np.ma.masked_array(frame[self.y_min:self.y_max, self.x_min:self.x_max], mask=where))

# -----------------------------------------------------------------
