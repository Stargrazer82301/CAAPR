PTS -- Python Toolkit for working with SKIRT
© Astronomical Observatory, Ghent University

The filter descriptions in this directory were downloaded from the filter profile service web site:
  http://svo2.cab.inta-csic.es/theory/fps

Thank you for providing this service!
